import '../../../core/app_export.dart';

/// This class is used in the [twentythree_item_widget] screen.
class TwentythreeItemModel {
  Rx<String>? burgerBtn = Rx("Burger");

  Rx<bool>? isSelected = Rx(false);
}
